package com.HappiestMinds.Persistent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HappiestMinds2Application {

	public static void main(String[] args) {
		SpringApplication.run(HappiestMinds2Application.class, args);
	}

}
