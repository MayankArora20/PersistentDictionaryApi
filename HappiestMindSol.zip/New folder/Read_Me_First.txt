
Technologies Used: Spring MVC,Spring BOOT, JPA, MYSQL, JSP

To keeep the dictionary Persistent so that event after a restart of system the dictionary values remains, I used MySQL, else I could have done it with H2. 

1.Just import the database file with name "hmdb.sql"
2.Import the project in eclipst/sts/any other spring supported IDE
3.start mysql on port 3306 which is default in most cases, 
   database username=root
	password=
  in case you want to change the username and password
  go to /HappiestMinds-2/src/main/resources/application.properties
  and update new username and password at line 3 and 4
4.On browser typer localhost:8080 and enjoy.....